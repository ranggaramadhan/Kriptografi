﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        RichTextBox2.Text = Atbash_Chipher(RichTextBox1.Text)


    End Sub

    Function Atbash_Chipher(ByVal input As String)
        Dim result As String = ""
        For Each x As Char In input

            If Char.IsLower(x) Then
                Dim diff As Integer = Asc(x) - Asc("a")
                result += Chr(Asc("z") - diff)

            ElseIf Char.IsUpper(x) Then
                Dim diff As Integer = Asc(x) - Asc("A")
                result += Chr(Asc("Z") - diff)
            Else
                result += x

            End If
        Next

        Return result

    End Function
End Class
